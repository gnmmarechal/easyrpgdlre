Controls:
Arrow keys - movement
Z - action; confirm
X - menu; cancel
1 - use effect ability
3 - cancel effect ability
5 - drop effect
9 - wake up

Gameplay:
- Go to sleep in the bed and open the door to enter the dream world.
- Explore the dream world and collect effects.
- The dream world is very large, so use landmarks to navigate: walk straight in one direction until you come across something to use as a landmark, then change direction and walk straight until you find another landmark, and so on.
- If you get lost or stuck, press 9 to wake up.
- You can save your game at the desk when you're awake.

Links:
Game website:  http://www3.nns.ne.jp/pri/tk-mto/main.htm

Description and download links:  http://zepy.momotato.com/2007/08/25/yume-nikki/
Game download:  http://www.vector.co.jp/soft/win95/game/se332192.html
RPG Maker 2003 runtime download:  http://www.famitsu.com/freegame/rtp/2003_rtp.html